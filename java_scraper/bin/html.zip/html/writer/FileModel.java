package html.writer;

public class FileModel {
	
	String fileName;
	String filePath;
	public FileModel(String fileName, String filePath) {
		super();
		this.fileName = fileName;
		this.filePath = filePath;
	}
	
}
